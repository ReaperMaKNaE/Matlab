t=-10:0.01:10;
x_1=function_3_1_A(t);
h_1=function_3_1_B(t);
subplot(2,1,1)
plot(t,x_1)
subplot(2,1,2)
plot(t,h_1)