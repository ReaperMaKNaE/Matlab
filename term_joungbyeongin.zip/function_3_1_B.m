function x = function_3_1_B(t)
x(t<=-1)=0;
x(t>=-1)=1;
x(t>1)=0;
end