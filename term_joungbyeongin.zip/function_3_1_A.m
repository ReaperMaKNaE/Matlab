function x = function_3_1_A(t)
x=sinc(t);
end