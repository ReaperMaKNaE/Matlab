n=1:60;
x_2=function_4_1_A(n);
h_2=function_4_1_B(n);
subplot(2,1,1)
stem(x_2)
subplot(2,1,2)
stem(h_2)