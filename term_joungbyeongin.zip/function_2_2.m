function x = function_2_2(t)
x=cos(2*pi*10.*t+pi/4)+cos(2*pi*30.*t+pi/4);