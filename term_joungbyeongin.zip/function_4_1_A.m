function x=function_4_1_A(n)
x=sin(2*pi.*n/10)+sin(2*pi.*n/20)+sin(2*pi.*n/30);
end
